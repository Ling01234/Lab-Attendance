#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include "zoomrecs.h"

//globale variable head
ZoomRecord head = NULL;


//create a method that frees the linked list
void freeNodes(ZoomRecord head){

ZoomRecord tmp;
while (head != NULL){
	tmp = head;
	head = head->next;
	free(tmp);

}
}

ZoomRecord addZoomRecord(ZoomRecord head, char* e, char* n, char lab, int time){
	//create a character array
	char line[200];

	if (head == NULL) {
		//make newnode to be head
		struct ZoomRecord* newnode = malloc(sizeof(struct ZoomRecord));
		
		if (newnode == NULL){
			exit(1);
		}
		//associate respective fields
		strcpy(newnode->email, e);
		strcpy(newnode->name, n);
		//set each duration to be 0
		for (int j = 0;j<9;j++){
			newnode->durations[j] = 0;
		}

		//update respective lab durations
		if (lab == 'A') newnode->durations[0] += time;
		else if (lab == 'B') newnode->durations[1] += time;
		else if (lab == 'C') newnode->durations[2] += time;
		else if (lab == 'D') newnode->durations[3] += time;
		else if (lab == 'E') newnode->durations[4] += time;
		else if (lab == 'F') newnode->durations[5] += time;
		else if (lab == 'G') newnode->durations[6] += time;
		else if (lab == 'H') newnode->durations[7] += time;
		else if (lab == 'I') newnode->durations[8] += time;

		return newnode; //return the newnode and store it as head
	}

	else{ //there is a head
		int test = 0; // make a testing variable

		struct ZoomRecord* tmp = malloc(sizeof(struct ZoomRecord));

		if (tmp == NULL){
			exit(1);
		}
		//check if head email is the same as given email
		tmp = head;
		if (strcmp(tmp->email, e) == 0){

			test = 1;
		}
		//iterate through linked list
		while(tmp->next != NULL){

			if (strcmp(tmp->email, e) == 0){

				test = 1; //email is already in the linked list
				break;
			}
			tmp = tmp->next;



		}

		if (test == 0){ //email is not in the linked list 
			//make a newnode
			struct ZoomRecord* newnode = malloc(sizeof(struct ZoomRecord));
			
			if (newnode == NULL){

				exit(1);
			}
			//update respective fields
			strcpy(newnode->email, e);
			strcpy(newnode->name, n);
			
			for (int j = 0;j<9;j++){
				newnode->durations[j] = 0;
			}
			//update respective lab time
			if (lab == 'A') newnode->durations[0] += time;
			else if (lab == 'B') newnode->durations[1] += time;
			else if (lab == 'C') newnode->durations[2] += time;
			else if (lab == 'D') newnode->durations[3] += time;
			else if (lab == 'E') newnode->durations[4] += time;
			else if (lab == 'F') newnode->durations[5] += time;
			else if (lab == 'G') newnode->durations[6] += time;
			else if (lab == 'H') newnode->durations[7] += time;
			else if (lab == 'I') newnode->durations[8] += time;

			if (strcmp(newnode->email, head->email) < 0) {//newnode should be placed before head
				newnode->next = head;
				head = newnode;
				return head;
			}

			else{ //newnode->email is greater than haed->email

				struct ZoomRecord* iteratingTmp = malloc(sizeof(struct ZoomRecord));

				if (iteratingTmp == NULL){
					exit(1);
				}


				iteratingTmp = head;
				//figure out where to place newnode
				while (iteratingTmp->next != NULL && strcmp(newnode->email, iteratingTmp->next->email) > 0){
					iteratingTmp = iteratingTmp->next;

				}
				//we're not at the end of the linked list
				if (iteratingTmp->next != NULL){
					newnode->next = iteratingTmp->next;
					iteratingTmp->next = newnode;
				}
				else{ //we're at the end of the list
					iteratingTmp->next = newnode;
					newnode->next = NULL;

				}


				return head;

			}



		}
		//update respective lab time	
		if (lab == 'A') tmp->durations[0] += time;
		else if (lab == 'B') tmp->durations[1] += time;
		else if (lab == 'C') tmp->durations[2] += time;
		else if (lab == 'D') tmp->durations[3] += time;
		else if (lab == 'E') tmp->durations[4] += time;
		else if (lab == 'F') tmp->durations[5] += time;
		else if (lab == 'G') tmp->durations[6] += time;
		else if (lab == 'H') tmp->durations[7] += time;
		else if (lab == 'I') tmp->durations[8] += time;

		return head;



	}




}



void generateAttendance(ZoomRecord head, char* outputFile){

	FILE* output = fopen(outputFile, "w");
	//write header to output
	fprintf(output, "User Email,Name (Original Name),A,B,C,D,E,F,G,H,I,Attendance (Percentage)\n");


	ZoomRecord tmp = malloc(sizeof(ZoomRecord));
	if (tmp == NULL){
		exit(1);
	}
	tmp = head;
	//do while loop to write out info for each node of linked list
	do{
		int counter = 0;//create counter variable

		for (int i = 0;i<9;i++){
			if (tmp->durations[i] >= 45){ //if lab time is greater than 45m
				counter++; //increment counter
			}

		}	

		float average = (float) counter/9 * 100; //attendance percentage

		fprintf(output, "%s,%s,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.2f\n", tmp->email, tmp->name, tmp->durations[0], tmp->durations[1], tmp->durations[2], tmp->durations[3], tmp->durations[4], tmp->durations[5], tmp->durations[6], tmp->durations[7], tmp->durations[8], average);
		
		if (tmp->next != NULL){ // we're not at the last node
			tmp = tmp->next;
		} 

		else{ //end of the linked list
			break;
		}
	} while(1);


	fclose(output);

}

