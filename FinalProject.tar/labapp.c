#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "zoomrecs.h"


extern ZoomRecord head;
//function declarations
ZoomRecord addZoomRecord(ZoomRecord zr, char* e, char* n, char lab, int time);
void generateAttendance(ZoomRecord zr, char* file2);
void freeNodes(ZoomRecord zr);



int main (int argc, char* argv[] ){
//open file
FILE* input = fopen(argv[1], "r");

char line[200];

//reads the header
fgets(line, 200, input);

//create a head for the linked list
ZoomRecord head = NULL;

//read file line by line
while(fgets(line,200,input)){


	//parse each field
	char *t = strtok(line, ","); 

	char E[100];
	char N[100];

	strcpy(E, t); //E contains the email of a ZoomRecord
	char lab;
	int time;
	
	for (int i = 0; i<3 && t != NULL; i++){
		//update each field of node
		t = strtok(NULL, ",");
		if (i == 0) strcpy(N, t);
		else if (i == 1) lab = *t;
		else if (i == 2) time = atoi(t);

	}
	//update head of linked list
	head = addZoomRecord(head, E, N, lab, time);

}
//generateAttendance
generateAttendance(head, argv[2]);

//free the linked list
freeNodes(head);

fclose(input);


}


