#!/bin/bash


if [[ $# -ne 2 ]]
then
echo "Usage fixformat.sh <dirname> <opfile>"
exit 1;
fi

if [[ ! -d "$1" ]]
then
echo "Error $1 is not a valid directory"
exit 1
fi


touch $2
chmod +x $2
#write the header of output file
echo "User Email,Name (Original Name),Lab,Total Duration (Minutes)" > $2


#iterate through each file that we find
for f in $(find $1 -iname 'lab-*.csv')
do
awk ' BEGIN { FS=","; OFS="," }
{ lab=substr(FILENAME, length(FILENAME)-4,1) } 

{ if (NR == 1 && $0 == "Name (Original Name),User Email,Total Duration (Minutes),Guest") check = 1}
{ if (NR != 1 && check == 1) print $2, $1, toupper(lab), $3 }

{ if (NR == 1 && $0 == "Name (Original Name),User Email,Join Time,Leave Time,Duration (Minutes),Guest") check = 2 }
{ if (NR != 1 && check == 2) print $2, $1, toupper(lab), $5 }
' $f >> $2


done


