#include<stdio.h>
#include<stdlib.h>
#include<string.h>

struct ZoomRecord
{
	char email[60];
	char name[60];
	int durations[9];
	struct ZoomRecord *next;
};
//make a type ZoomRecord
typedef struct ZoomRecord *ZoomRecord;



